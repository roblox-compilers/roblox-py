"""Name constant description"""


class NameConstantDesc:
    """Name constant description"""

    NAME = {
        None: "nil",
        True: "true",
        False: "false",
    }
